using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
	

	public enum ContainmentKind  
	{
	    FREE = 0,
	    HORIZONTAL_ARRANGEMENT = 1,
	    VERTICAL_ARRANGEMENT = 2,
	    EXTERNAL_LINK = 3  
	}


