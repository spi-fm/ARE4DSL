using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
	

	public enum OutlineKind  
	{
	    SIMPLE = 0,
	    DOUBLE = 1,
	    NONE = 2  
	}


