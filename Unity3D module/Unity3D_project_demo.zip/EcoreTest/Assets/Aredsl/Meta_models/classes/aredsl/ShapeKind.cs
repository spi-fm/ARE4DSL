using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
	

	public enum ShapeKind  
	{
	    CIRCLE = 0,
	    SQUARE = 1,
	    RECTANGLE = 2,
	    ELLIPSE = 3,
	    DIAMOND = 4,
	    TRIANGLE = 5  
	}


