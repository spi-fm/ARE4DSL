using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class LabelStyle: MonoBehaviour
{
 public string _color;
 public int _height;
 public string _semanticCondition;
 
 



		// Start is called before the first frame update
	    void Start()
	    {
	        
	    }
	
	    // Update is called once per frame
	    void Update()
	    {
	        
	    }
	}
	

