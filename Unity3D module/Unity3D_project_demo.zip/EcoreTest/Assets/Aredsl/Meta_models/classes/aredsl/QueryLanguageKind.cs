using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
	

	public enum QueryLanguageKind  
	{
	    LINQ = 0,
	    JPQL = 1,
	    SQL = 2,
	    AQL = 3,
	    OCL = 4,
	    XPATH_XQUERY = 5  
	}


