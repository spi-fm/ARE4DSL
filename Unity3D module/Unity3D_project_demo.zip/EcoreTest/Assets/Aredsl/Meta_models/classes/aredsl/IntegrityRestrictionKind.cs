using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
	

	public enum IntegrityRestrictionKind  
	{
	    CASCADE = 0,
	    SET_NULL = 1,
	    NO_ACTION = 2  
	}


