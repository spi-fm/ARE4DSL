using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Collections.Generic;


public class Node: MonoBehaviour
{
 public string _id;
 public string _semantics;
 public ContainmentKind _contaimentKind;
 public string _description;
 
 public List<NodeStyle> nodestyles;
 public Label label;
 public List<Node> contentNodes;
 



		// Start is called before the first frame update
	    void Start()
	    {
	        
	    }
	
	    // Update is called once per frame
	    void Update()
	    {
	        
	    }
	}
	

