using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GeometricShapeNodeStyle : NodeStyle
{
 public string _color;
 public ShapeKind _kind;
 public OutlineKind _outline;
 
 



		// Start is called before the first frame update
	    void Start()
	    {
	        
	    }
	
	    // Update is called once per frame
	    void Update()
	    {
	        
	    }
	}
	

