using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
	

	public enum LineKind  
	{
	    SOLID = 0,
	    DASHED = 1,
	    DOTTED = 2  
	}


