using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Collections.Generic;


public class Tool: MonoBehaviour
{
 public string _id;
 public string _description;
 public string _precondition;
 public string _targetPrecondition;
 
 public List<Behaviour> behaviours;
 public List<Action> actions;
 



		// Start is called before the first frame update
	    void Start()
	    {
	        
	    }
	
	    // Update is called once per frame
	    void Update()
	    {
	        
	    }
	}
	

