using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Collections.Generic;


public class Layer: MonoBehaviour
{
 public string _id;
 public string _semantics;
 public string _description;
 
 public List<Node> nodes;
 public List<Edge> edges;
 public TrackerAction referenceAction;
 



		// Start is called before the first frame update
	    void Start()
	    {
	        
	    }
	
	    // Update is called once per frame
	    void Update()
	    {
	        
	    }
	}
	

