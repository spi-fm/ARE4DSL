using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Collections.Generic;


public class Edge: MonoBehaviour
{
 public string _id;
 public string _originSemantics;
 public string _destinationSemantics;
 public string _description;
 
 public List<EdgeStyle> edgestyles;
 public Label middleLabel;
 public Node originNode;
 public Node destinationNode;
 public Label originLabel;
 public Label destinationLabel;
 



		// Start is called before the first frame update
	    void Start()
	    {
	        
	    }
	
	    // Update is called once per frame
	    void Update()
	    {
	        
	    }
	}
	

