using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Attribute: MonoBehaviour
{
 public string _name;
 public DATATYPE _dataType;
 public bool _foreignKey;
 public bool _isPrimaryKey;
 
 



		// Start is called before the first frame update
	    void Start()
	    {
	        
	    }
	
	    // Update is called once per frame
	    void Update()
	    {
	        
	    }
	}
	

