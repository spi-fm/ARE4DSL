using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
	

	public enum DATATYPE  
	{
	    INTEGER = 0,
	    DATE = 1,
	    FLOAT = 2,
	    STRING = 3  
	}


