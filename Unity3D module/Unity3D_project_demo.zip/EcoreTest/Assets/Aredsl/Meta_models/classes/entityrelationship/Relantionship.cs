using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Collections.Generic;


public class Relantionship: MonoBehaviour
{
 public string _name;
 public string _sourceCardinality;
 public string _targetCardinality;
 
 public Entity source;
 public Entity target;
 public List<Attribute> attributes;
 



		// Start is called before the first frame update
	    void Start()
	    {
	        
	    }
	
	    // Update is called once per frame
	    void Update()
	    {
	        
	    }
	}
	

